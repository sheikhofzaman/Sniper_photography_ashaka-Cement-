<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';

header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

if (!isLoggedIn()) {
    $response['message'] = 'Unauthorized';
    echo json_encode($response);
    exit;
}

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Mark as read when viewing
$update = $conn->prepare("UPDATE messages SET is_read = 1 WHERE id = ?");
$update->bind_param("i", $id);
$update->execute();
$update->close();

$stmt = $conn->prepare("SELECT * FROM messages WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $response['success'] = true;
    $response['message'] = $result->fetch_assoc();
} else {
    $response['message'] = 'Message not found';
}

$stmt->close();
echo json_encode($response);
?>

<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

$message = '';
$error = '';

// Handle delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);

    // Get image path first
    $stmt = $conn->prepare("SELECT image_path FROM gallery WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $image = $result->fetch_assoc();
        $imagePath = '../' . $image['image_path'];

        if (file_exists($imagePath)) {
            unlink($imagePath);
        }

        $deleteStmt = $conn->prepare("DELETE FROM gallery WHERE id = ?");
        $deleteStmt->bind_param("i", $id);
        if ($deleteStmt->execute()) {
            $message = 'Image deleted successfully';
        } else {
            $error = 'Failed to delete image';
        }
        $deleteStmt->close();
    }
    $stmt->close();
}

// Get all gallery items
$gallery = $conn->query("SELECT g.*, c.name as category_name FROM gallery g LEFT JOIN categories c ON g.category = c.slug ORDER BY g.created_at DESC");

// Get categories for upload form
$categories = $conn->query("SELECT * FROM categories ORDER BY name");

$pageTitle = 'Gallery';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?> | Sniper Photography Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body class="admin-body">
    <div class="admin-wrapper">
        <aside class="admin-sidebar">
            <div class="sidebar-header">
                <div class="logo-icon"><i class="fas fa-camera"></i></div>
                <h3>Sniper <span>Photo</span></h3>
            </div>
            <ul class="sidebar-menu">
                <li><a href="index.php"><i class="fas fa-tachometer-alt"></i> <span class="menu-text">Dashboard</span></a></li>
                <li><a href="bookings.php"><i class="fas fa-calendar-check"></i> <span class="menu-text">Bookings</span></a></li>
                <li><a href="gallery.php" class="active"><i class="fas fa-images"></i> <span class="menu-text">Gallery</span></a></li>
                <li><a href="services.php"><i class="fas fa-concierge-bell"></i> <span class="menu-text">Services</span></a></li>
                <li><a href="testimonials.php"><i class="fas fa-star"></i> <span class="menu-text">Testimonials</span></a></li>
                <li><a href="messages.php"><i class="fas fa-envelope"></i> <span class="menu-text">Messages</span></a></li>
                <li><a href="settings.php"><i class="fas fa-cog"></i> <span class="menu-text">Settings</span></a></li>
            </ul>
            <div class="sidebar-divider"></div>
            <ul class="sidebar-menu">
                <li><a href="../index.php" target="_blank"><i class="fas fa-external-link-alt"></i> <span class="menu-text">View Website</span></a></li>
                <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> <span class="menu-text">Logout</span></a></li>
            </ul>
            <div class="sidebar-user">
                <div class="user-avatar"><?php echo strtoupper(substr($_SESSION['full_name'], 0, 1)); ?></div>
                <div class="user-info">
                    <h4><?php echo htmlspecialchars($_SESSION['full_name']); ?></h4>
                    <p><?php echo ucfirst($_SESSION['role']); ?></p>
                </div>
            </div>
        </aside>

        <main class="admin-main">
            <div class="admin-topbar">
                <div class="topbar-left">
                    <button class="sidebar-toggle"><i class="fas fa-bars"></i></button>
                    <div class="breadcrumb">
                        <a href="index.php">Admin</a>
                        <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
                        <span>Gallery</span>
                    </div>
                </div>
            </div>

            <div class="admin-content">
                <div class="page-header">
                    <h2>Manage Gallery</h2>
                    <p>Upload and manage your portfolio images</p>
                </div>

                <?php if ($message): ?>
                <div class="alert success" style="background: rgba(40, 167, 69, 0.1); border: 1px solid #28a745; color: #28a745; padding: 15px; border-radius: 10px; margin-bottom: 20px;">
                    <i class="fas fa-check-circle"></i> <?php echo $message; ?>
                </div>
                <?php endif; ?>

                <?php if ($error): ?>
                <div class="alert error" style="background: rgba(220, 53, 69, 0.1); border: 1px solid #dc3545; color: #dc3545; padding: 15px; border-radius: 10px; margin-bottom: 20px;">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
                <?php endif; ?>

                <!-- Upload Form -->
                <div class="table-card" style="margin-bottom: 30px;">
                    <div class="table-header">
                        <h3>Upload New Image</h3>
                    </div>
                    <form id="uploadForm" enctype="multipart/form-data">
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
                            <div class="form-group">
                                <label>Image Title</label>
                                <input type="text" name="title" required placeholder="Enter image title">
                            </div>
                            <div class="form-group">
                                <label>Category</label>
                                <select name="category" required>
                                    <option value="">Select category</option>
                                    <?php while($cat = $categories->fetch_assoc()): ?>
                                    <option value="<?php echo $cat['slug']; ?>"><?php echo $cat['name']; ?></option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Description</label>
                            <textarea name="description" rows="3" placeholder="Enter image description"></textarea>
                        </div>
                        <div class="form-group">
                            <label>
                                <input type="checkbox" name="is_featured"> Feature this image on homepage
                            </label>
                        </div>
                        <div class="image-upload" style="margin-bottom: 20px;">
                            <input type="file" name="image" accept="image/*" required data-preview="#imagePreview" style="display: none;">
                            <i class="fas fa-cloud-upload-alt"></i>
                            <p>Drag & drop image here or click to browse</p>
                            <p style="color: #888; font-size: 12px; margin-top: 10px;">Supported: JPG, PNG, GIF, WebP (Max 5MB)</p>
                            <img id="imagePreview" style="display: none; max-width: 200px; margin-top: 15px; border-radius: 10px;">
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-upload"></i> Upload Image
                        </button>
                    </form>
                </div>

                <!-- Gallery Grid -->
                <div class="table-card">
                    <div class="table-header">
                        <h3>Gallery Images</h3>
                        <input type="text" class="table-search" data-table="galleryTable" placeholder="Search images..." style="padding: 8px 15px; background: #0f0f0f; border: 1px solid #2a2a2a; border-radius: 8px; color: #fff;">
                    </div>
                    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 20px;" id="galleryTable">
                        <?php while($item = $gallery->fetch_assoc()): ?>
                        <div style="background: #0f0f0f; border-radius: 15px; overflow: hidden; border: 1px solid #2a2a2a;">
                            <div style="aspect-ratio: 4/3; overflow: hidden;">
                                <img src="../<?php echo $item['image_path']; ?>" alt="<?php echo htmlspecialchars($item['title']); ?>" style="width: 100%; height: 100%; object-fit: cover;">
                            </div>
                            <div style="padding: 20px;">
                                <h4 style="margin-bottom: 5px; font-size: 16px;"><?php echo htmlspecialchars($item['title']); ?></h4>
                                <p style="color: #888; font-size: 13px; margin-bottom: 10px;"><?php echo htmlspecialchars($item['category_name'] ?: $item['category']); ?></p>
                                <div style="display: flex; justify-content: space-between; align-items: center;">
                                    <?php if($item['is_featured']): ?>
                                    <span style="background: rgba(212, 175, 55, 0.1); color: #D4AF37; padding: 3px 10px; border-radius: 5px; font-size: 11px;">Featured</span>
                                    <?php else: ?>
                                    <span></span>
                                    <?php endif; ?>
                                    <a href="gallery.php?delete=<?php echo $item['id']; ?>" class="action-btn delete delete-btn" title="Delete"><i class="fas fa-trash"></i></a>
                                </div>
                            </div>
                        </div>
                        <?php endwhile; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script src="../assets/js/admin.js"></script>
    <script>
        document.getElementById('uploadForm').addEventListener('submit', async function(e) {
            e.preventDefault();

            const formData = new FormData(this);
            const btn = this.querySelector('button[type="submit"]');

            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Uploading...';

            try {
                const response = await fetch('../api/gallery-upload.php', {
                    method: 'POST',
                    body: formData
                });

                const result = await response.json();

                if (result.success) {
                    showToast('Image uploaded successfully', 'success');
                    this.reset();
                    document.getElementById('imagePreview').style.display = 'none';
                    setTimeout(() => location.reload(), 1500);
                } else {
                    showToast(result.message, 'error');
                }
            } catch (error) {
                showToast('Upload failed', 'error');
            } finally {
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-upload"></i> Upload Image';
            }
        });
    </script>
</body>
</html>

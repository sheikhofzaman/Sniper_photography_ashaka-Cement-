<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';

// Check if logged in
if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

// Get stats
$stats = [
    'bookings' => $conn->query("SELECT COUNT(*) as count FROM bookings")->fetch_assoc()['count'],
    'pending_bookings' => $conn->query("SELECT COUNT(*) as count FROM bookings WHERE status = 'pending'")->fetch_assoc()['count'],
    'messages' => $conn->query("SELECT COUNT(*) as count FROM messages WHERE is_read = 0")->fetch_assoc()['count'],
    'gallery' => $conn->query("SELECT COUNT(*) as count FROM gallery")->fetch_assoc()['count'],
    'revenue' => $conn->query("SELECT COALESCE(SUM(price), 0) as total FROM bookings WHERE status = 'completed'")->fetch_assoc()['total'],
    'clients' => $conn->query("SELECT COUNT(DISTINCT client_email) as count FROM bookings")->fetch_assoc()['count']
];

// Recent bookings
$recentBookings = $conn->query("SELECT * FROM bookings ORDER BY created_at DESC LIMIT 5");

// Recent messages
$recentMessages = $conn->query("SELECT * FROM messages ORDER BY created_at DESC LIMIT 5");

$pageTitle = 'Dashboard';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?> | Sniper Photography Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="admin-body">
    <div class="admin-wrapper">
        <!-- Sidebar -->
        <aside class="admin-sidebar">
            <div class="sidebar-header">
                <div class="logo-icon"><i class="fas fa-camera"></i></div>
                <h3>Sniper <span>Photo</span></h3>
            </div>

            <ul class="sidebar-menu">
                <li><a href="index.php" class="active"><i class="fas fa-tachometer-alt"></i> <span class="menu-text">Dashboard</span></a></li>
                <li><a href="bookings.php"><i class="fas fa-calendar-check"></i> <span class="menu-text">Bookings</span></a></li>
                <li><a href="gallery.php"><i class="fas fa-images"></i> <span class="menu-text">Gallery</span></a></li>
                <li><a href="services.php"><i class="fas fa-concierge-bell"></i> <span class="menu-text">Services</span></a></li>
                <li><a href="testimonials.php"><i class="fas fa-star"></i> <span class="menu-text">Testimonials</span></a></li>
                <li><a href="messages.php"><i class="fas fa-envelope"></i> <span class="menu-text">Messages</span> <?php if($stats['messages'] > 0): ?><span class="badge"><?php echo $stats['messages']; ?></span><?php endif; ?></a></li>
                <li><a href="settings.php"><i class="fas fa-cog"></i> <span class="menu-text">Settings</span></a></li>
            </ul>

            <div class="sidebar-divider"></div>

            <ul class="sidebar-menu">
                <li><a href="../index.php" target="_blank"><i class="fas fa-external-link-alt"></i> <span class="menu-text">View Website</span></a></li>
                <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> <span class="menu-text">Logout</span></a></li>
            </ul>

            <div class="sidebar-user">
                <div class="user-avatar"><?php echo strtoupper(substr($_SESSION['full_name'], 0, 1)); ?></div>
                <div class="user-info">
                    <h4><?php echo htmlspecialchars($_SESSION['full_name']); ?></h4>
                    <p><?php echo ucfirst($_SESSION['role']); ?></p>
                </div>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="admin-main">
            <!-- Top Bar -->
            <div class="admin-topbar">
                <div class="topbar-left">
                    <button class="sidebar-toggle"><i class="fas fa-bars"></i></button>
                    <div class="breadcrumb">
                        <a href="index.php">Admin</a>
                        <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
                        <span>Dashboard</span>
                    </div>
                </div>
                <div class="topbar-right">
                    <button class="topbar-btn" title="Notifications">
                        <i class="fas fa-bell"></i>
                        <?php if($stats['messages'] > 0): ?><span class="badge"><?php echo $stats['messages']; ?></span><?php endif; ?>
                    </button>
                    <button class="topbar-btn" title="Messages">
                        <i class="fas fa-envelope"></i>
                    </button>
                </div>
            </div>

            <!-- Content -->
            <div class="admin-content">
                <div class="page-header">
                    <h2>Dashboard Overview</h2>
                    <p>Welcome back, <?php echo htmlspecialchars($_SESSION['full_name']); ?>! Here's what's happening.</p>
                </div>

                <!-- Stats Grid -->
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-header">
                            <h4>Total Bookings</h4>
                            <div class="stat-icon gold"><i class="fas fa-calendar-check"></i></div>
                        </div>
                        <div class="stat-value"><?php echo number_format($stats['bookings']); ?></div>
                        <div class="stat-change up"><i class="fas fa-arrow-up"></i> Active bookings</div>
                    </div>

                    <div class="stat-card">
                        <div class="stat-header">
                            <h4>Pending Bookings</h4>
                            <div class="stat-icon blue"><i class="fas fa-clock"></i></div>
                        </div>
                        <div class="stat-value"><?php echo number_format($stats['pending_bookings']); ?></div>
                        <div class="stat-change up"><i class="fas fa-arrow-up"></i> Needs attention</div>
                    </div>

                    <div class="stat-card">
                        <div class="stat-header">
                            <h4>Total Revenue</h4>
                            <div class="stat-icon green"><i class="fas fa-naira-sign"></i></div>
                        </div>
                        <div class="stat-value">₦<?php echo number_format($stats['revenue']); ?></div>
                        <div class="stat-change up"><i class="fas fa-arrow-up"></i> From completed</div>
                    </div>

                    <div class="stat-card">
                        <div class="stat-header">
                            <h4>Total Clients</h4>
                            <div class="stat-icon purple"><i class="fas fa-users"></i></div>
                        </div>
                        <div class="stat-value"><?php echo number_format($stats['clients']); ?></div>
                        <div class="stat-change up"><i class="fas fa-arrow-up"></i> Unique clients</div>
                    </div>
                </div>

                <!-- Charts Row -->
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 30px;">
                    <div class="table-card">
                        <div class="table-header">
                            <h3>Bookings Overview</h3>
                        </div>
                        <div style="height: 300px;">
                            <canvas id="bookingsChart"></canvas>
                        </div>
                    </div>
                    <div class="table-card">
                        <div class="table-header">
                            <h3>Revenue Overview</h3>
                        </div>
                        <div style="height: 300px;">
                            <canvas id="revenueChart"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Recent Bookings -->
                <div class="table-card">
                    <div class="table-header">
                        <h3>Recent Bookings</h3>
                        <a href="bookings.php" class="btn btn-primary" style="padding: 8px 20px; font-size: 12px;">View All</a>
                    </div>
                    <div style="overflow-x: auto;">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Client</th>
                                    <th>Service</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($booking = $recentBookings->fetch_assoc()): ?>
                                <tr>
                                    <td>#<?php echo $booking['id']; ?></td>
                                    <td>
                                        <strong><?php echo htmlspecialchars($booking['client_name']); ?></strong><br>
                                        <small style="color: #888;"><?php echo htmlspecialchars($booking['client_email']); ?></small>
                                    </td>
                                    <td><?php echo htmlspecialchars($booking['service_type']); ?></td>
                                    <td><?php echo date('M d, Y', strtotime($booking['event_date'])); ?></td>
                                    <td><span class="status <?php echo $booking['status']; ?>"><?php echo ucfirst($booking['status']); ?></span></td>
                                    <td>
                                        <a href="bookings.php?view=<?php echo $booking['id']; ?>" class="action-btn view" title="View"><i class="fas fa-eye"></i></a>
                                        <a href="bookings.php?edit=<?php echo $booking['id']; ?>" class="action-btn edit" title="Edit"><i class="fas fa-edit"></i></a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Recent Messages -->
                <div class="table-card">
                    <div class="table-header">
                        <h3>Recent Messages</h3>
                        <a href="messages.php" class="btn btn-primary" style="padding: 8px 20px; font-size: 12px;">View All</a>
                    </div>
                    <div style="overflow-x: auto;">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Subject</th>
                                    <th>Message</th>
                                    <th>Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($msg = $recentMessages->fetch_assoc()): ?>
                                <tr style="<?php echo $msg['is_read'] ? '' : 'background: rgba(212, 175, 55, 0.05);'; ?>">
                                    <td>
                                        <strong><?php echo htmlspecialchars($msg['name']); ?></strong><br>
                                        <small style="color: #888;"><?php echo htmlspecialchars($msg['email']); ?></small>
                                    </td>
                                    <td><?php echo htmlspecialchars($msg['subject'] ?: 'No Subject'); ?></td>
                                    <td><?php echo substr(htmlspecialchars($msg['message']), 0, 50) . '...'; ?></td>
                                    <td><?php echo date('M d, Y', strtotime($msg['created_at'])); ?></td>
                                    <td>
                                        <a href="messages.php?view=<?php echo $msg['id']; ?>" class="action-btn view" title="View"><i class="fas fa-eye"></i></a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script src="../assets/js/admin.js"></script>
</body>
</html>

<?php
// Login Process - Sniper Photography Admin
// Created by: Abubakar Musa

require_once '../includes/auth.php';

header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $response['message'] = 'Invalid request method';
    echo json_encode($response);
    exit;
}

$username = isset($_POST['username']) ? trim($_POST['username']) : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';

if (empty($username) || empty($password)) {
    $response['message'] = 'Please enter both username and password';
    echo json_encode($response);
    exit;
}

$result = login($username, $password);

if ($result['success']) {
    $response['success'] = true;
    $response['message'] = 'Login successful! Redirecting...';
} else {
    $response['message'] = $result['message'];
}

echo json_encode($response);
?>

<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

$message = '';
$error = '';

// Mark as read
if (isset($_GET['read'])) {
    $id = intval($_GET['read']);
    $stmt = $conn->prepare("UPDATE messages SET is_read = 1 WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
}

// Handle delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $stmt = $conn->prepare("DELETE FROM messages WHERE id = ?");
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        $message = 'Message deleted successfully';
    } else {
        $error = 'Failed to delete message';
    }
    $stmt->close();
}

// Get all messages
$messages = $conn->query("SELECT * FROM messages ORDER BY created_at DESC");

$pageTitle = 'Messages';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?> | Sniper Photography Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body class="admin-body">
    <div class="admin-wrapper">
        <aside class="admin-sidebar">
            <div class="sidebar-header">
                <div class="logo-icon"><i class="fas fa-camera"></i></div>
                <h3>Sniper <span>Photo</span></h3>
            </div>
            <ul class="sidebar-menu">
                <li><a href="index.php"><i class="fas fa-tachometer-alt"></i> <span class="menu-text">Dashboard</span></a></li>
                <li><a href="bookings.php"><i class="fas fa-calendar-check"></i> <span class="menu-text">Bookings</span></a></li>
                <li><a href="gallery.php"><i class="fas fa-images"></i> <span class="menu-text">Gallery</span></a></li>
                <li><a href="services.php"><i class="fas fa-concierge-bell"></i> <span class="menu-text">Services</span></a></li>
                <li><a href="testimonials.php"><i class="fas fa-star"></i> <span class="menu-text">Testimonials</span></a></li>
                <li><a href="messages.php" class="active"><i class="fas fa-envelope"></i> <span class="menu-text">Messages</span></a></li>
                <li><a href="settings.php"><i class="fas fa-cog"></i> <span class="menu-text">Settings</span></a></li>
            </ul>
            <div class="sidebar-divider"></div>
            <ul class="sidebar-menu">
                <li><a href="../index.php" target="_blank"><i class="fas fa-external-link-alt"></i> <span class="menu-text">View Website</span></a></li>
                <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> <span class="menu-text">Logout</span></a></li>
            </ul>
            <div class="sidebar-user">
                <div class="user-avatar"><?php echo strtoupper(substr($_SESSION['full_name'], 0, 1)); ?></div>
                <div class="user-info">
                    <h4><?php echo htmlspecialchars($_SESSION['full_name']); ?></h4>
                    <p><?php echo ucfirst($_SESSION['role']); ?></p>
                </div>
            </div>
        </aside>

        <main class="admin-main">
            <div class="admin-topbar">
                <div class="topbar-left">
                    <button class="sidebar-toggle"><i class="fas fa-bars"></i></button>
                    <div class="breadcrumb">
                        <a href="index.php">Admin</a>
                        <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
                        <span>Messages</span>
                    </div>
                </div>
            </div>

            <div class="admin-content">
                <div class="page-header">
                    <h2>Contact Messages</h2>
                    <p>View and manage messages from website visitors</p>
                </div>

                <?php if ($message): ?>
                <div class="alert success" style="background: rgba(40, 167, 69, 0.1); border: 1px solid #28a745; color: #28a745; padding: 15px; border-radius: 10px; margin-bottom: 20px;">
                    <i class="fas fa-check-circle"></i> <?php echo $message; ?>
                </div>
                <?php endif; ?>

                <?php if ($error): ?>
                <div class="alert error" style="background: rgba(220, 53, 69, 0.1); border: 1px solid #dc3545; color: #dc3545; padding: 15px; border-radius: 10px; margin-bottom: 20px;">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
                <?php endif; ?>

                <div class="table-card">
                    <div class="table-header">
                        <h3>All Messages</h3>
                        <input type="text" class="table-search" data-table="messagesTable" placeholder="Search messages..." style="padding: 8px 15px; background: #0f0f0f; border: 1px solid #2a2a2a; border-radius: 8px; color: #fff;">
                    </div>
                    <div style="overflow-x: auto;">
                        <table class="data-table" id="messagesTable">
                            <thead>
                                <tr>
                                    <th>Status</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Subject</th>
                                    <th>Message</th>
                                    <th>Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($msg = $messages->fetch_assoc()): ?>
                                <tr style="<?php echo $msg['is_read'] ? '' : 'background: rgba(212, 175, 55, 0.05); font-weight: 600;'; ?>">
                                    <td>
                                        <?php if(!$msg['is_read']): ?>
                                        <span style="background: #D4AF37; color: #0a0a0a; padding: 3px 10px; border-radius: 5px; font-size: 11px;">New</span>
                                        <?php else: ?>
                                        <span style="background: #2a2a2a; color: #888; padding: 3px 10px; border-radius: 5px; font-size: 11px;">Read</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($msg['name']); ?></td>
                                    <td><a href="mailto:<?php echo $msg['email']; ?>" style="color: #D4AF37;"><?php echo htmlspecialchars($msg['email']); ?></a></td>
                                    <td><?php echo htmlspecialchars($msg['subject'] ?: 'No Subject'); ?></td>
                                    <td><?php echo substr(htmlspecialchars($msg['message']), 0, 60) . '...'; ?></td>
                                    <td><?php echo date('M d, Y H:i', strtotime($msg['created_at'])); ?></td>
                                    <td>
                                        <?php if(!$msg['is_read']): ?>
                                        <a href="messages.php?read=<?php echo $msg['id']; ?>" class="action-btn view" title="Mark as Read"><i class="fas fa-check"></i></a>
                                        <?php endif; ?>
                                        <button class="action-btn view" onclick="viewMessage(<?php echo $msg['id']; ?>)" title="View"><i class="fas fa-eye"></i></button>
                                        <a href="messages.php?delete=<?php echo $msg['id']; ?>" class="action-btn delete delete-btn" title="Delete"><i class="fas fa-trash"></i></a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <!-- Message Modal -->
    <div id="messageModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.8); z-index: 2000; justify-content: center; align-items: center;">
        <div style="background: #1a1a1a; border-radius: 20px; padding: 40px; max-width: 600px; width: 90%; max-height: 80vh; overflow-y: auto; border: 1px solid #2a2a2a;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
                <h3>Message Details</h3>
                <button onclick="closeMessageModal()" style="background: none; border: none; color: #fff; font-size: 24px; cursor: pointer;"><i class="fas fa-times"></i></button>
            </div>
            <div id="messageDetails"></div>
        </div>
    </div>

    <script src="../assets/js/admin.js"></script>
    <script>
        function viewMessage(id) {
            fetch('api/get-message.php?id=' + id)
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        const m = data.message;
                        document.getElementById('messageDetails').innerHTML = `
                            <div style="display: grid; gap: 15px;">
                                <div style="padding: 15px; background: #0f0f0f; border-radius: 10px;">
                                    <label style="color: #888; font-size: 12px;">From</label>
                                    <p style="font-size: 16px; margin-top: 5px;">${m.name}</p>
                                </div>
                                <div style="padding: 15px; background: #0f0f0f; border-radius: 10px;">
                                    <label style="color: #888; font-size: 12px;">Email</label>
                                    <p style="font-size: 16px; margin-top: 5px;"><a href="mailto:${m.email}" style="color: #D4AF37;">${m.email}</a></p>
                                </div>
                                <div style="padding: 15px; background: #0f0f0f; border-radius: 10px;">
                                    <label style="color: #888; font-size: 12px;">Subject</label>
                                    <p style="font-size: 16px; margin-top: 5px;">${m.subject || 'No Subject'}</p>
                                </div>
                                <div style="padding: 15px; background: #0f0f0f; border-radius: 10px;">
                                    <label style="color: #888; font-size: 12px;">Message</label>
                                    <p style="font-size: 16px; margin-top: 5px; line-height: 1.8;">${m.message}</p>
                                </div>
                                <div style="padding: 15px; background: #0f0f0f; border-radius: 10px;">
                                    <label style="color: #888; font-size: 12px;">Received</label>
                                    <p style="font-size: 16px; margin-top: 5px;">${new Date(m.created_at).toLocaleString()}</p>
                                </div>
                            </div>
                        `;
                        document.getElementById('messageModal').style.display = 'flex';
                    }
                });
        }

        function closeMessageModal() {
            document.getElementById('messageModal').style.display = 'none';
        }
    </script>
</body>
</html>

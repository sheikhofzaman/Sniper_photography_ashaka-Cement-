<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

$message = '';
$error = '';

// Handle delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $stmt = $conn->prepare("DELETE FROM services WHERE id = ?");
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        $message = 'Service deleted successfully';
    } else {
        $error = 'Failed to delete service';
    }
    $stmt->close();
}

// Get all services
$services = $conn->query("SELECT * FROM services ORDER BY sort_order, id");

$pageTitle = 'Services';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?> | Sniper Photography Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body class="admin-body">
    <div class="admin-wrapper">
        <aside class="admin-sidebar">
            <div class="sidebar-header">
                <div class="logo-icon"><i class="fas fa-camera"></i></div>
                <h3>Sniper <span>Photo</span></h3>
            </div>
            <ul class="sidebar-menu">
                <li><a href="index.php"><i class="fas fa-tachometer-alt"></i> <span class="menu-text">Dashboard</span></a></li>
                <li><a href="bookings.php"><i class="fas fa-calendar-check"></i> <span class="menu-text">Bookings</span></a></li>
                <li><a href="gallery.php"><i class="fas fa-images"></i> <span class="menu-text">Gallery</span></a></li>
                <li><a href="services.php" class="active"><i class="fas fa-concierge-bell"></i> <span class="menu-text">Services</span></a></li>
                <li><a href="testimonials.php"><i class="fas fa-star"></i> <span class="menu-text">Testimonials</span></a></li>
                <li><a href="messages.php"><i class="fas fa-envelope"></i> <span class="menu-text">Messages</span></a></li>
                <li><a href="settings.php"><i class="fas fa-cog"></i> <span class="menu-text">Settings</span></a></li>
            </ul>
            <div class="sidebar-divider"></div>
            <ul class="sidebar-menu">
                <li><a href="../index.php" target="_blank"><i class="fas fa-external-link-alt"></i> <span class="menu-text">View Website</span></a></li>
                <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> <span class="menu-text">Logout</span></a></li>
            </ul>
            <div class="sidebar-user">
                <div class="user-avatar"><?php echo strtoupper(substr($_SESSION['full_name'], 0, 1)); ?></div>
                <div class="user-info">
                    <h4><?php echo htmlspecialchars($_SESSION['full_name']); ?></h4>
                    <p><?php echo ucfirst($_SESSION['role']); ?></p>
                </div>
            </div>
        </aside>

        <main class="admin-main">
            <div class="admin-topbar">
                <div class="topbar-left">
                    <button class="sidebar-toggle"><i class="fas fa-bars"></i></button>
                    <div class="breadcrumb">
                        <a href="index.php">Admin</a>
                        <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
                        <span>Services</span>
                    </div>
                </div>
            </div>

            <div class="admin-content">
                <div class="page-header">
                    <h2>Manage Services</h2>
                    <p>View and manage photography services and pricing</p>
                </div>

                <?php if ($message): ?>
                <div class="alert success" style="background: rgba(40, 167, 69, 0.1); border: 1px solid #28a745; color: #28a745; padding: 15px; border-radius: 10px; margin-bottom: 20px;">
                    <i class="fas fa-check-circle"></i> <?php echo $message; ?>
                </div>
                <?php endif; ?>

                <?php if ($error): ?>
                <div class="alert error" style="background: rgba(220, 53, 69, 0.1); border: 1px solid #dc3545; color: #dc3545; padding: 15px; border-radius: 10px; margin-bottom: 20px;">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
                <?php endif; ?>

                <div class="table-card">
                    <div class="table-header">
                        <h3>All Services</h3>
                        <a href="services-edit.php" class="btn btn-primary" style="padding: 8px 20px; font-size: 12px;"><i class="fas fa-plus"></i> Add Service</a>
                    </div>
                    <div style="overflow-x: auto;">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Service</th>
                                    <th>Description</th>
                                    <th>Price</th>
                                    <th>Duration</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($service = $services->fetch_assoc()): ?>
                                <tr>
                                    <td>#<?php echo $service['id']; ?></td>
                                    <td>
                                        <div style="display: flex; align-items: center; gap: 10px;">
                                            <div style="width: 40px; height: 40px; background: linear-gradient(135deg, #D4AF37, #B8860B); border-radius: 10px; display: flex; align-items: center; justify-content: center; color: #0a0a0a;">
                                                <i class="fas <?php echo $service['icon']; ?>"></i>
                                            </div>
                                            <strong><?php echo htmlspecialchars($service['title']); ?></strong>
                                        </div>
                                    </td>
                                    <td><?php echo substr(htmlspecialchars($service['description']), 0, 60) . '...'; ?></td>
                                    <td style="color: #D4AF37; font-weight: 700;">₦<?php echo number_format($service['price']); ?></td>
                                    <td><?php echo htmlspecialchars($service['duration']); ?></td>
                                    <td>
                                        <span class="status <?php echo $service['is_active'] ? 'approved' : 'cancelled'; ?>">
                                            <?php echo $service['is_active'] ? 'Active' : 'Inactive'; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a href="services-edit.php?id=<?php echo $service['id']; ?>" class="action-btn edit" title="Edit"><i class="fas fa-edit"></i></a>
                                        <a href="services.php?delete=<?php echo $service['id']; ?>" class="action-btn delete delete-btn" title="Delete"><i class="fas fa-trash"></i></a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script src="../assets/js/admin.js"></script>
</body>
</html>

<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

$message = '';
$error = '';

// Get current settings
$settingsResult = $conn->query("SELECT * FROM settings");
$settings = [];
while($row = $settingsResult->fetch_assoc()) {
    $settings[$row['setting_key']] = $row['setting_value'];
}

// Handle password change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $currentPassword = $_POST['current_password'];
    $newPassword = $_POST['new_password'];
    $confirmPassword = $_POST['confirm_password'];

    if ($newPassword !== $confirmPassword) {
        $error = 'New passwords do not match';
    } else if (strlen($newPassword) < 6) {
        $error = 'Password must be at least 6 characters';
    } else {
        $result = changePassword($_SESSION['user_id'], $currentPassword, $newPassword);
        if ($result['success']) {
            $message = 'Password changed successfully';
        } else {
            $error = $result['message'];
        }
    }
}

$pageTitle = 'Settings';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?> | Sniper Photography Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body class="admin-body">
    <div class="admin-wrapper">
        <aside class="admin-sidebar">
            <div class="sidebar-header">
                <div class="logo-icon"><i class="fas fa-camera"></i></div>
                <h3>Sniper <span>Photo</span></h3>
            </div>
            <ul class="sidebar-menu">
                <li><a href="index.php"><i class="fas fa-tachometer-alt"></i> <span class="menu-text">Dashboard</span></a></li>
                <li><a href="bookings.php"><i class="fas fa-calendar-check"></i> <span class="menu-text">Bookings</span></a></li>
                <li><a href="gallery.php"><i class="fas fa-images"></i> <span class="menu-text">Gallery</span></a></li>
                <li><a href="services.php"><i class="fas fa-concierge-bell"></i> <span class="menu-text">Services</span></a></li>
                <li><a href="testimonials.php"><i class="fas fa-star"></i> <span class="menu-text">Testimonials</span></a></li>
                <li><a href="messages.php"><i class="fas fa-envelope"></i> <span class="menu-text">Messages</span></a></li>
                <li><a href="settings.php" class="active"><i class="fas fa-cog"></i> <span class="menu-text">Settings</span></a></li>
            </ul>
            <div class="sidebar-divider"></div>
            <ul class="sidebar-menu">
                <li><a href="../index.php" target="_blank"><i class="fas fa-external-link-alt"></i> <span class="menu-text">View Website</span></a></li>
                <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> <span class="menu-text">Logout</span></a></li>
            </ul>
            <div class="sidebar-user">
                <div class="user-avatar"><?php echo strtoupper(substr($_SESSION['full_name'], 0, 1)); ?></div>
                <div class="user-info">
                    <h4><?php echo htmlspecialchars($_SESSION['full_name']); ?></h4>
                    <p><?php echo ucfirst($_SESSION['role']); ?></p>
                </div>
            </div>
        </aside>

        <main class="admin-main">
            <div class="admin-topbar">
                <div class="topbar-left">
                    <button class="sidebar-toggle"><i class="fas fa-bars"></i></button>
                    <div class="breadcrumb">
                        <a href="index.php">Admin</a>
                        <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
                        <span>Settings</span>
                    </div>
                </div>
            </div>

            <div class="admin-content">
                <div class="page-header">
                    <h2>Settings</h2>
                    <p>Manage your account and website settings</p>
                </div>

                <?php if ($message): ?>
                <div class="alert success" style="background: rgba(40, 167, 69, 0.1); border: 1px solid #28a745; color: #28a745; padding: 15px; border-radius: 10px; margin-bottom: 20px;">
                    <i class="fas fa-check-circle"></i> <?php echo $message; ?>
                </div>
                <?php endif; ?>

                <?php if ($error): ?>
                <div class="alert error" style="background: rgba(220, 53, 69, 0.1); border: 1px solid #dc3545; color: #dc3545; padding: 15px; border-radius: 10px; margin-bottom: 20px;">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
                <?php endif; ?>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px;">
                    <!-- Change Password -->
                    <div class="table-card">
                        <div class="table-header">
                            <h3><i class="fas fa-lock"></i> Change Password</h3>
                        </div>
                        <form method="POST" class="admin-form">
                            <input type="hidden" name="change_password" value="1">
                            <div class="form-group">
                                <label>Current Password</label>
                                <input type="password" name="current_password" required>
                            </div>
                            <div class="form-group">
                                <label>New Password</label>
                                <input type="password" name="new_password" required minlength="6">
                            </div>
                            <div class="form-group">
                                <label>Confirm New Password</label>
                                <input type="password" name="confirm_password" required minlength="6">
                            </div>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-key"></i> Change Password
                            </button>
                        </form>
                    </div>

                    <!-- Site Info -->
                    <div class="table-card">
                        <div class="table-header">
                            <h3><i class="fas fa-info-circle"></i> Site Information</h3>
                        </div>
                        <div style="display: grid; gap: 20px;">
                            <div style="padding: 20px; background: #0f0f0f; border-radius: 10px;">
                                <label style="color: #888; font-size: 12px; text-transform: uppercase;">Site Title</label>
                                <p style="font-size: 18px; margin-top: 5px;"><?php echo htmlspecialchars($settings['site_title'] ?? 'Sniper Photography'); ?></p>
                            </div>
                            <div style="padding: 20px; background: #0f0f0f; border-radius: 10px;">
                                <label style="color: #888; font-size: 12px; text-transform: uppercase;">Tagline</label>
                                <p style="font-size: 16px; margin-top: 5px;"><?php echo htmlspecialchars($settings['site_tagline'] ?? 'Capturing Moments with Precision'); ?></p>
                            </div>
                            <div style="padding: 20px; background: #0f0f0f; border-radius: 10px;">
                                <label style="color: #888; font-size: 12px; text-transform: uppercase;">Owner</label>
                                <p style="font-size: 16px; margin-top: 5px;"><?php echo htmlspecialchars($settings['owner_name'] ?? 'Abubakar Musa'); ?></p>
                            </div>
                            <div style="padding: 20px; background: #0f0f0f; border-radius: 10px;">
                                <label style="color: #888; font-size: 12px; text-transform: uppercase;">Contact Email</label>
                                <p style="font-size: 16px; margin-top: 5px;"><?php echo htmlspecialchars($settings['contact_email'] ?? 'abubakar@sniperphotography.com'); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script src="../assets/js/admin.js"></script>
</body>
</html>

<?php
// Booking API with Paystack Payment - Sniper Photography
// Created by: Abubakar Musa

require_once '../includes/db.php';
require_once '../includes/payment-config.php';

header('Content-Type: application/json');

$response = ['success' => false, 'message' => '', 'booking_id' => 0, 'payment_required' => true];

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $response['message'] = 'Invalid request method';
    echo json_encode($response);
    exit;
}

// Get and sanitize input
$name = isset($_POST['name']) ? trim(htmlspecialchars($_POST['name'])) : '';
$email = isset($_POST['email']) ? trim(filter_var($_POST['email'], FILTER_SANITIZE_EMAIL)) : '';
$phone = isset($_POST['phone']) ? trim(htmlspecialchars($_POST['phone'])) : '';
$eventDate = isset($_POST['event_date']) ? $_POST['event_date'] : '';
$eventTime = isset($_POST['event_time']) ? $_POST['event_time'] : '';
$serviceType = isset($_POST['service_type']) ? trim(htmlspecialchars($_POST['service_type'])) : '';
$location = isset($_POST['location']) ? trim(htmlspecialchars($_POST['location'])) : '';
$message = isset($_POST['message']) ? trim(htmlspecialchars($_POST['message'])) : '';

// Validation
$errors = [];

if (empty($name)) $errors[] = 'Name is required';
if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required';
if (empty($phone)) $errors[] = 'Phone number is required';
if (empty($eventDate)) $errors[] = 'Event date is required';
if (empty($serviceType)) $errors[] = 'Service type is required';

if (!empty($errors)) {
    $response['message'] = implode(', ', $errors);
    echo json_encode($response);
    exit;
}

// Check if date is in the future
$eventDateTime = strtotime($eventDate);
if ($eventDateTime < strtotime('today')) {
    $response['message'] = 'Event date must be in the future';
    echo json_encode($response);
    exit;
}

// Get service price
$priceStmt = $conn->prepare("SELECT price FROM services WHERE title = ? AND is_active = TRUE");
$priceStmt->bind_param("s", $serviceType);
$priceStmt->execute();
$priceResult = $priceStmt->get_result();
$servicePrice = 0;

if ($priceResult->num_rows === 1) {
    $serviceData = $priceResult->fetch_assoc();
    $servicePrice = floatval($serviceData['price']);
}
$priceStmt->close();

// Insert booking
$stmt = $conn->prepare("INSERT INTO bookings (client_name, client_email, client_phone, event_date, event_time, service_type, location, message, status, price, payment_status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?, 'unpaid', NOW())");
$stmt->bind_param("ssssssssd", $name, $email, $phone, $eventDate, $eventTime, $serviceType, $location, $message, $servicePrice);

if ($stmt->execute()) {
    $bookingId = $stmt->insert_id;
    $response['success'] = true;
    $response['booking_id'] = $bookingId;
    $response['price'] = $servicePrice;
    $response['message'] = 'Booking submitted! Please complete payment to confirm.';

    // If price is 0, no payment needed
    if ($servicePrice <= 0) {
        $response['payment_required'] = false;
        $response['message'] = 'Booking submitted successfully! We will contact you soon.';
    }
} else {
    $response['message'] = 'Failed to submit booking. Please try again.';
}

$stmt->close();
echo json_encode($response);
?>

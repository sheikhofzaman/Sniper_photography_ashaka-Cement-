<?php
// Gallery Upload API - Sniper Photography
// Created by: Abubakar Musa

require_once '../includes/db.php';
require_once '../includes/auth.php';

header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

if (!isLoggedIn()) {
    $response['message'] = 'Unauthorized';
    echo json_encode($response);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $response['message'] = 'Invalid request method';
    echo json_encode($response);
    exit;
}

$title = isset($_POST['title']) ? trim(htmlspecialchars($_POST['title'])) : '';
$description = isset($_POST['description']) ? trim(htmlspecialchars($_POST['description'])) : '';
$category = isset($_POST['category']) ? trim(htmlspecialchars($_POST['category'])) : '';
$isFeatured = isset($_POST['is_featured']) ? 1 : 0;

if (empty($title) || empty($category)) {
    $response['message'] = 'Title and category are required';
    echo json_encode($response);
    exit;
}

// Handle file upload
if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
    $response['message'] = 'Please select an image to upload';
    echo json_encode($response);
    exit;
}

$file = $_FILES['image'];
$allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
$maxSize = 5 * 1024 * 1024; // 5MB

if (!in_array($file['type'], $allowedTypes)) {
    $response['message'] = 'Invalid file type. Only JPG, PNG, GIF, and WebP are allowed.';
    echo json_encode($response);
    exit;
}

if ($file['size'] > $maxSize) {
    $response['message'] = 'File size too large. Maximum size is 5MB.';
    echo json_encode($response);
    exit;
}

// Generate unique filename
$ext = pathinfo($file['name'], PATHINFO_EXTENSION);
$filename = uniqid('gallery_') . '.' . $ext;
$uploadPath = '../assets/uploads/gallery/' . $filename;

if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
    // Create thumbnail
    $thumbFilename = 'thumb_' . $filename;
    $thumbPath = '../assets/uploads/gallery/' . $thumbFilename;
    createThumbnail($uploadPath, $thumbPath, 400, 300);

    $imagePath = 'assets/uploads/gallery/' . $filename;
    $thumbPath = 'assets/uploads/gallery/' . $thumbFilename;

    $stmt = $conn->prepare("INSERT INTO gallery (title, description, category, image_path, thumbnail_path, is_featured, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())");
    $stmt->bind_param("sssssi", $title, $description, $category, $imagePath, $thumbPath, $isFeatured);

    if ($stmt->execute()) {
        $response['success'] = true;
        $response['message'] = 'Image uploaded successfully';
        $response['image_id'] = $stmt->insert_id;
    } else {
        $response['message'] = 'Failed to save to database';
        unlink($uploadPath);
    }
    $stmt->close();
} else {
    $response['message'] = 'Failed to upload file';
}

echo json_encode($response);

function createThumbnail($src, $dest, $width, $height) {
    list($w, $h, $type) = getimagesize($src);

    switch($type) {
        case IMAGETYPE_JPEG: $srcImg = imagecreatefromjpeg($src); break;
        case IMAGETYPE_PNG: $srcImg = imagecreatefrompng($src); break;
        case IMAGETYPE_GIF: $srcImg = imagecreatefromgif($src); break;
        default: return false;
    }

    $thumb = imagecreatetruecolor($width, $height);
    imagecopyresampled($thumb, $srcImg, 0, 0, 0, 0, $width, $height, $w, $h);

    switch($type) {
        case IMAGETYPE_JPEG: imagejpeg($thumb, $dest, 85); break;
        case IMAGETYPE_PNG: imagepng($thumb, $dest, 8); break;
        case IMAGETYPE_GIF: imagegif($thumb, $dest); break;
    }

    imagedestroy($srcImg);
    imagedestroy($thumb);
    return true;
}
?>

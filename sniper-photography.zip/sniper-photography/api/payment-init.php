<?php
// Initialize Paystack Payment
// Sniper Photography - Abubakar Musa

require_once '../includes/db.php';
require_once '../includes/payment-config.php';

header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $response['message'] = 'Invalid request method';
    echo json_encode($response);
    exit;
}

// Get booking details
$bookingId = isset($_POST['booking_id']) ? intval($_POST['booking_id']) : 0;
$email = isset($_POST['email']) ? trim($_POST['email']) : '';
$amount = isset($_POST['amount']) ? floatval($_POST['amount']) : 0;

if ($bookingId <= 0 || empty($email) || $amount <= 0) {
    $response['message'] = 'Invalid payment details';
    echo json_encode($response);
    exit;
}

// Get booking info
$stmt = $conn->prepare("SELECT * FROM bookings WHERE id = ?");
$stmt->bind_param("i", $bookingId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    $response['message'] = 'Booking not found';
    echo json_encode($response);
    exit;
}

$booking = $result->fetch_assoc();
$stmt->close();

// Generate unique reference
$reference = 'SNP_' . $bookingId . '_' . time() . '_' . rand(1000, 9999);

// Amount in kobo (Paystack uses smallest currency unit)
$amountKobo = $amount * 100;

// Paystack Secret Key
$secretKey = getPaystackSecretKey();

// Initialize transaction with Paystack
$url = 'https://api.paystack.co/transaction/initialize';

$fields = [
    'email' => $email,
    'amount' => $amountKobo,
    'reference' => $reference,
    'callback_url' => (isset($_SERVER['HTTPS']) ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] . dirname(dirname($_SERVER['PHP_SELF'])) . '/payment-callback.php',
    'metadata' => json_encode([
        'booking_id' => $bookingId,
        'custom_fields' => [
            [
                'display_name' => 'Client Name',
                'variable_name' => 'client_name',
                'value' => $booking['client_name']
            ],
            [
                'display_name' => 'Service Type',
                'variable_name' => 'service_type',
                'value' => $booking['service_type']
            ]
        ]
    ])
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($fields));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Authorization: Bearer ' . $secretKey,
    'Cache-Control: no-cache'
]);

$paystackResponse = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$paystackData = json_decode($paystackResponse, true);

if ($httpCode === 200 && $paystackData['status'] === true) {
    // Save payment record
    $paymentStmt = $conn->prepare("INSERT INTO payments (booking_id, reference, amount, email, status, created_at) VALUES (?, ?, ?, ?, 'pending', NOW())");
    $paymentStmt->bind_param("isds", $bookingId, $reference, $amount, $email);
    $paymentStmt->execute();
    $paymentStmt->close();

    // Update booking with reference
    $updateStmt = $conn->prepare("UPDATE bookings SET payment_reference = ?, price = ? WHERE id = ?");
    $updateStmt->bind_param("sdi", $reference, $amount, $bookingId);
    $updateStmt->execute();
    $updateStmt->close();

    $response['success'] = true;
    $response['authorization_url'] = $paystackData['data']['authorization_url'];
    $response['reference'] = $reference;
    $response['access_code'] = $paystackData['data']['access_code'];
} else {
    $response['message'] = $paystackData['message'] ?? 'Payment initialization failed';
}

echo json_encode($response);
?>

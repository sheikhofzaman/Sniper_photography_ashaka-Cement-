<?php
// Update Status API - Sniper Photography
// Created by: Abubakar Musa

require_once '../includes/db.php';
require_once '../includes/auth.php';

header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

if (!isLoggedIn()) {
    $response['message'] = 'Unauthorized';
    echo json_encode($response);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $response['message'] = 'Invalid request method';
    echo json_encode($response);
    exit;
}

$id = isset($_POST['id']) ? intval($_POST['id']) : 0;
$status = isset($_POST['status']) ? trim(htmlspecialchars($_POST['status'])) : '';
$type = isset($_POST['type']) ? trim(htmlspecialchars($_POST['type'])) : '';

$validStatuses = ['pending', 'approved', 'completed', 'cancelled'];
if (!in_array($status, $validStatuses)) {
    $response['message'] = 'Invalid status';
    echo json_encode($response);
    exit;
}

if ($type === 'booking') {
    $stmt = $conn->prepare("UPDATE bookings SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $status, $id);

    if ($stmt->execute()) {
        $response['success'] = true;
        $response['message'] = 'Booking status updated';
    } else {
        $response['message'] = 'Failed to update status';
    }
    $stmt->close();
} else {
    $response['message'] = 'Invalid type';
}

echo json_encode($response);
?>

<?php
// Authentication Functions
// Sniper Photography - Abubakar Musa

require_once 'db.php';

// Login function
function login($username, $password) {
    global $conn;

    $stmt = $conn->prepare("SELECT id, username, password_hash, full_name, role, avatar FROM users WHERE username = ? OR email = ?");
    $stmt->bind_param("ss", $username, $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password_hash'])) {
            // Update last login
            $update = $conn->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
            $update->bind_param("i", $user['id']);
            $update->execute();

            // Set session
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['avatar'] = $user['avatar'];
            $_SESSION['logged_in'] = true;

            return ['success' => true, 'message' => 'Login successful'];
        }
    }

    return ['success' => false, 'message' => 'Invalid username or password'];
}

// Check if logged in
function isLoggedIn() {
    return isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true;
}

// Check if admin
function isAdmin() {
    return isLoggedIn() && $_SESSION['role'] === 'admin';
}

// Logout function
function logout() {
    session_destroy();
    return ['success' => true, 'message' => 'Logged out successfully'];
}

// Change password
function changePassword($userId, $currentPassword, $newPassword) {
    global $conn;

    $stmt = $conn->prepare("SELECT password_hash FROM users WHERE id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        if (password_verify($currentPassword, $user['password_hash'])) {
            $newHash = password_hash($newPassword, PASSWORD_DEFAULT);
            $update = $conn->prepare("UPDATE users SET password_hash = ? WHERE id = ?");
            $update->bind_param("si", $newHash, $userId);
            if ($update->execute()) {
                return ['success' => true, 'message' => 'Password changed successfully'];
            }
        }
        return ['success' => false, 'message' => 'Current password is incorrect'];
    }

    return ['success' => false, 'message' => 'User not found'];
}

// Require auth middleware
function requireAuth() {
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit();
    }
}

// CSRF Token
function generateCSRFToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function validateCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}
?>

<?php
// Paystack Payment Configuration
// Sniper Photography - Abubakar Musa
// Get your keys from: https://dashboard.paystack.com/#/settings/developer

// Fetch keys from database
function getPaystackKeys() {
    global $conn;
    $result = $conn->query("SELECT * FROM paystack_settings LIMIT 1");
    if ($result && $result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    return null;
}

function getPaystackPublicKey() {
    $keys = getPaystackKeys();
    return $keys ? $keys['public_key'] : 'pk_test_your_public_key_here';
}

function getPaystackSecretKey() {
    $keys = getPaystackKeys();
    return $keys ? $keys['secret_key'] : 'sk_test_your_secret_key_here';
}

function isPaystackLive() {
    $keys = getPaystackKeys();
    return $keys ? (bool)$keys['is_live'] : false;
}
?>

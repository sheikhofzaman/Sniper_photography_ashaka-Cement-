<?php
// EMERGENCY PASSWORD RESET
// Run this file to reset admin password to 'admin123'
// DELETE THIS FILE AFTER USE!

require_once 'includes/db.php';

$newHash = password_hash('admin123', PASSWORD_DEFAULT);

$stmt = $conn->prepare("UPDATE users SET password_hash = ? WHERE username = 'admin'");
$stmt->bind_param("s", $newHash);

if ($stmt->execute()) {
    echo "✅ Password reset successfully!<br>";
    echo "Username: admin<br>";
    echo "Password: admin123<br><br>";
    echo "<strong>DELETE THIS FILE IMMEDIATELY FOR SECURITY!</strong>";
} else {
    echo "❌ Failed to reset password: " . $stmt->error;
}

$stmt->close();
?>
